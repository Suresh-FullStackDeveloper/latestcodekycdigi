import Axios from 'axios'
import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class IndSummary extends Component {
  // continue = e => {
  //   e.preventDefault()
  //   this.props.nextStep()
  // }
  iddd = JSON.parse(localStorage.getItem('id'))

  back = e => {
    e.preventDefault()
    this.props.prevStep()
  }

  handleSubmitClick = async e => {
    e.preventDefault()

    try {
      const { user } = this.props
      const config = {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      }

      await Axios.post('http://kycdigi.ae:4002/personal/personalinfo', user, {
        config
      }).then(function (response) {
        if (response.status === 200) {
          console.log('error', response.data)
        } else {
          this.props.showError('Some error ocurred')
        }
      })
    } catch (error) {
      if (error.response) {
        console.log('error', error.response.data)
      }
    }
  }

  // add entity - POST

  // creates entity
  Idd = JSON.parse(localStorage.getItem('id'))

  render () {
    //  const { firstname, profession, emiratesid } = this.props

    //  const { firstname, profession, emiratesid } = this.props
    //Idd = JSON.parse(localStorage.getItem('id'))

    const {
      values: { iddd, firstname, Profession, emiratesIdNumber }
    } = this.props

    // const {
    //   firstname,
    //   // lastname,
    //   // email,
    //   // phone,
    //   // //coursesChosenSummary,
    //   // //chosenLevel,
    //   submitData
    // } = this.props

    return (
      <div className='form'>
        <div>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { label: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={3}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='summary'>
            <h2 className='summary__heading'>Confirm your personal details</h2>
            <div>
              <div>
                <p>
                  <span className='summary__item-title'>First Name:</span>
                  {JSON.parse(localStorage.getItem('id'))}
                </p>
                <p>
                  <span className='summary__item-title'>First Name:</span>
                  {firstname}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Profession :</span>{' '}
                  {emiratesIdNumber}
                </p>
              </div>
              <div>
                <p>
                  <span className='summary__item-title'>Emirates ID:</span>{' '}
                  {Profession}
                </p>
              </div>
            </div>
          </div>

          <div className='summary'>
            <h2 className='summary__heading'>Confirm your All details</h2>
            <div>
              <div>
                <p>
                  {/* <span className='summary__item-title'>Level:</span>{' '}
                  {chosenLevel} */}
                </p>
              </div>
              <div>
                <div>
                  {/* <span className='summary__item-title'>Courses:</span>{' '}
                  {coursesChosenSummary} */}
                </div>
              </div>
            </div>
          </div>

          <div className='buttons'>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              type='submit'
              onClick={this.handleSubmitClick}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    )
  }
}

export default IndSummary
