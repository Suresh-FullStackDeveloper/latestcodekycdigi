import React, { Component, useState } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'

class CorpPersonalDetails extends Component {
  continue = e => {
    e.preventDefault()
    // const isFirstNameValid = this.props.validateFirstName()
    //   const isLastNameValid = this.props.validateLastName()
    // if (isFirstNameValid && isLastNameValid) {
    //   this.props.nextStep()
    // }
    this.props.nextStep()
  }
  IndPersonalDetails = () => {
    /*  Initial State */
    let [Name, setname] = useState('')

    /* The handleChange() function to set a new state for input */
    const handleChange = event => {
      setname(event.target.value)
    }
  }

  render () {
    const {
      firstname,
      middlename,
      lastname,
      residentialstatus,
      POBox,
      ShopNo,
      Buildingname,
      Street,
      City,
      Emirate,
      Country,
      Countryofincorporation,
      MobileNumber,
      Phonenumber,
      FaxNumber,
      EmailID,
      DateofEstablishment,
      IDtype,

      tradelicense,
      Tradelicensenumber,
      Tradelicenseplaceofissue,
      Tradelicenseissuedate,
      Tradelicenseexpirydate,
      Typeofbusinessoftheentity,
      Shareholders,
      Partners,
      NamesofUBO,
      IDdetailsofUBO,
      IDtypeofUBO,
      IDnumbersofUBO,
      Methodofpayment,
      cash,
      cheque,
      Nameofthepersonrepresentingtheentity,
      IDtypeofAuthPerson,
      IDnumbersofAuthPerson,
      Sourceoffunds,
      Purposeoftransaction,
      Beneficiaryname,
      bankaccountdetails,
      Expectedannualactivity,
      expectedannualvalue,
      numberoftransactionsfuturetransmonitoring,

      // email,
      // phone,
      handleChange,
      validateFirstName,
      validateLastName,
      isErrorFirstName,
      isErrorLastName,
      errorMessageFirstName,
      errorMessageLastName,
      validateMiddleName,
      isErrorMiddleName,
      errorMessageMiddleName,
      ResidentialStatus,
      isErrorResidentialStatus,
      errorMessageResidentialStatus,
      Area,
      isErrordateofbirth,
      errorMessagedateofbirth,
      isErrorcoutnryofbirth,
      errorMessagecoutnryofbirth
    } = this.props

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { lable: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={1}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '5em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='firstname' className='form-group__label'>
                First name
              </label>
              <input
                type='text'
                value={firstname}
                name='first name'
                onChange={'firstname'}
                onBlur={validateFirstName}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorFirstName && errorMessageFirstName}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='middle name' className='form-group__label'>
                Middle name
              </label>
              <input
                type='text'
                value={middlename}
                name='middle name'
                onChange={'middlename'}
                onBlur={validateMiddleName}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorMiddleName && errorMessageMiddleName}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='last name' className='form-group__label'>
                Last name
              </label>
              <input
                type='text'
                value={lastname}
                name='last name'
                onChange={'lastname'}
                onBlur={validateLastName}
                className='form-group__input'
              />
              <p className='error'>{isErrorLastName && errorMessageLastName}</p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='residentialstatus' className='form-group__label'>
                Residential Status
              </label>
              <input
                type='text'
                value={residentialstatus}
                name='residential status'
                onChange={'residentialstatus'}
                onBlur={ResidentialStatus}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorResidentialStatus && errorMessageResidentialStatus}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='POBox' className='form-group__label'>
                POBox
              </label>
              <input
                type='text'
                value={POBox}
                name='POBox'
                onChange={'POBox'}
                onBlur={POBox}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='ShopNo' className='form-group__label'>
                Shop No
              </label>
              <input
                type='ShopNo'
                value={ShopNo}
                name='ShopNo'
                onChange={'ShopNo'}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Buildingname' className='form-group__label'>
                Building name
              </label>
              <input
                type='text'
                value={Buildingname}
                name='Buildingname'
                onChange={'Buildingname'}
                // onBlur={City}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='Street' className='form-group__label'>
                Street
              </label>
              <input
                type='text'
                value={Street}
                name='Street'
                onChange={'Street'}
                onBlur={Street}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='City' className='form-group__label'>
                City
              </label>
              <input
                type='text'
                value={City}
                name='City'
                onChange={'City'}
                onBlur={City}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorprovince && errorMessageemiratesorprovince}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='Emirate' className='form-group__label'>
                Emirate
              </label>
              <input
                type='text'
                value={Emirate}
                name='Emirate'
                onChange={'Emirate'}
                onBlur={Emirate}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorcountry && errorMessageemiratesorcountry}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='Country' className='form-group__label'>
                Country
              </label>
              <input
                type='text'
                value={Country}
                name='Country'
                onChange={'Country'}
                onBlur={Country}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrortemporaryaddress && errorMessagetemporaryaddress}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label
                htmlFor='Countryofincorporation'
                className='form-group__label'
              >
                Country of incorporation
              </label>
              <input
                type='text'
                value={Countryofincorporation}
                name='Countryofincorporation'
                onChange={'Countryofincorporation'}
                onBlur={Countryofincorporation}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorpermanentaddress && errorMessagepermanentaddress}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='MobileNumber' className='form-group__label'>
                Mobile Number
              </label>
              <input
                type='text'
                value={MobileNumber}
                name='MobileNumber'
                onChange={'MobileNumber'}
                onBlur={MobileNumber}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorcompletepermanentaddress &&
                  errorMessagecompletepermanentaddress}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='FaxNumber' className='form-group__label'>
                Fax Number
              </label>
              <input
                type='text'
                value={FaxNumber}
                name='FaxNumber'
                onChange={'FaxNumber'}
                onBlur={FaxNumber}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrornationality && errorMessagenationality}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='EmailID' className='form-group__label'>
                Email ID
              </label>
              <input
                type='text'
                value={EmailID}
                name='EmailID'
                onChange={'EmailID'}
                onBlur={EmailID}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrordateofbirth && errorMessagedateofbirth}
              </p> */}
            </div>

            <div className='form-group__element'>
              <label
                htmlFor='DateofEstablishment'
                className='form-group__label'
              >
                Date of Establishment
              </label>
              <input
                type='text'
                value={DateofEstablishment}
                name='DateofEstablishment'
                onChange={'DateofEstablishment'}
                onBlur={DateofEstablishment}
                className='form-group__input'
              />
              {/* <p className='error'>
                {isErrorcoutnryofbirth && errorMessagecoutnryofbirth}
              </p> */}
            </div>
            <div className='form-group__element'>
              <label htmlFor='IDtype' className='form-group__label'>
                ID type
              </label>
              <input
                type='text'
                value={IDtype}
                name='IDtype'
                onChange={'IDtype'}
                className='form-group__input'
              />
            </div>
          </div>

          <div style={{ textAlign: 'center' }}>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default CorpPersonalDetails
