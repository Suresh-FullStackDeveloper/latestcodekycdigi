import React, { Component } from 'react'
import { Stepper } from 'react-form-stepper'
import '../../App.css'
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core'

class CorpAddressDetails extends Component {
  shouldComponentUpdate (nextProps) {
    if (
      this.props.emiratesid !== nextProps.isEmiratesId ||
      this.props.level !== nextProps.level
    ) {
      return true
    } else {
      return false
    }
  }
  continue = e => {
    e.preventDefault()
    // const isEmiratesId = this.props.validateEmiratesId()
    // const isPassport = this.props.validatePassport()
    // if (isEmiratesId && isPassport) {
    this.props.nextStep()
    // }
  }

  render () {
    const {
      emiratesid,
      passport,
      gccnationalid,
      idnumber,
      idplaceofissue,
      idissuedate,
      idexpirydate,

      // email,
      // phone,
      handleChange,
      validateEmiratesId,
      validatePassport,
      isErrorEmiratesId,
      isErrorPassport,
      errorMessageEmiratesId,
      errorMessagePassport
    } = this.props
    const theme = createMuiTheme({
      palette: {
        primary: {
          main: '#003487'
        },
        secondary: {
          main: '#003487'
        }
      },
      overrides: {
        MuiPaper: {
          elevation2: {
            boxShadow: 'none'
          }
        },
        MuiInput: {
          underline: {
            '&:before': {
              borderBottom: 'none'
            },
            '&:after': {
              borderBottom: 'none'
            },
            '&:hover': {
              '&:not(.Mui-disabled)': {
                '&:before': {
                  borderBottom: 'none'
                }
              }
            }
          }
        },
        MuiTableRow: {
          root: {
            '&:nth-child(even)': {
              backgroundColor: '#ebebeb'
            }
          }
        },
        MuiTypography: {
          h6: {
            fontSize: '1rem',
            color: '#011b64'
          }
        },
        MuiToolbar: {
          root: {
            borderBottom: '1px solid grey',
            backgroundColor: '#fafafa'
          },
          gutters: {
            paddingLeft: '3px'
          }
        }
      }
    })

    return (
      <div className='form'>
        <form>
          <Stepper
            steps={[
              { label: 'Personal details' },
              { label: 'Address details' },
              { lable: 'Payment Details' },
              { label: 'Summary' }
            ]}
            activeStep={2}
            styleConfig={{
              activeBgColor: '#2b7cff',
              activeTextColor: '#fff',
              inactiveBgColor: '#fff',
              inactiveTextColor: '#2b7cff',
              completedBgColor: '#fff',
              completedTextColor: '#2b7cff',
              size: '3em'
            }}
            className={'stepper'}
            stepClassName={'stepper__step'}
          />

          <div className='form-group'>
            <div className='form-group__element'>
              <label htmlFor='emirates id' className='form-group__label'>
                Emirates Id
              </label>
              <input
                type='text'
                value={emiratesid}
                name='emirates id'
                onChange={handleChange('emiratesid')}
                onBlur={validateEmiratesId}
                className='form-group__input'
              />
              <p className='error'>
                {isErrorEmiratesId && errorMessageEmiratesId}
              </p>
            </div>
            <div className='form-group__element'>
              <label htmlFor='passport' className='form-group__label'>
                Passport
              </label>
              <input
                type='text'
                value={passport}
                name='passport'
                onChange={handleChange('passport')}
                onBlur={validatePassport}
                className='form-group__input'
              />
              <p className='error'>{isErrorPassport && errorMessagePassport}</p>
            </div>

            <div className='form-group__element'>
              <label htmlFor='gccnationalid' className='form-group__label'>
                Gcc National Id
              </label>
              <input
                type='gccnationalid'
                value={gccnationalid}
                name='gccnationalid'
                onChange={handleChange('gccnationalid')}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='idnumber' className='form-group__label'>
                Id Number
              </label>
              <input
                type='text'
                value={idnumber}
                name='idnumber'
                onChange={handleChange('idnumber')}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='idplaceofissue' className='form-group__label'>
                ID Place of Issue
              </label>
              <input
                type='text'
                value={idplaceofissue}
                name='idplaceofissue'
                onChange={handleChange('idplaceofissue')}
                onBlur={idplaceofissue}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='idissuedate' className='form-group__label'>
                ID Issue Date
              </label>
              <input
                type='text'
                value={idissuedate}
                name='idissuedate'
                onChange={handleChange('idissuedate')}
                onBlur={idissuedate}
                className='form-group__input'
              />
            </div>
            <div className='form-group__element'>
              <label htmlFor='idexpirydate' className='form-group__label'>
                ID Expiry Date
              </label>
              <input
                type='text'
                value={idexpirydate}
                name='idexpirydate'
                onChange={handleChange('idexpirydate')}
                onBlur={idexpirydate}
                className='form-group__input'
              />
            </div>
          </div>

          <div className='table'>
            <MuiThemeProvider theme={theme}></MuiThemeProvider>
          </div>

          <div className='buttons'>
            <button
              className='buttons__button buttons__button--back'
              onClick={this.back}
            >
              Back
            </button>
            <button
              className='buttons__button buttons__button--next'
              onClick={this.continue}
            >
              Next
            </button>
          </div>
        </form>
      </div>
    )
  }
}

export default CorpAddressDetails
